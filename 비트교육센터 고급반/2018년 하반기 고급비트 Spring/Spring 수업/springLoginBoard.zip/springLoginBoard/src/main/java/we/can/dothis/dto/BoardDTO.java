package we.can.dothis.dto;

public class BoardDTO {
	private String BID;
	private String ID;
	private String BTITLE;
	private String BCONTENT;
	
	public String getBID() {
		return BID;
	}
	public void setBID(String bID) {
		BID = bID;
	}
	public String getID() {
		return ID;
	}
	public void setID(String iD) {
		ID = iD;
	}
	public String getBTITLE() {
		return BTITLE;
	}
	public void setBTITLE(String bTITLE) {
		BTITLE = bTITLE;
	}
	public String getBCONTENT() {
		return BCONTENT;
	}
	public void setBCONTENT(String bCONTENT) {
		BCONTENT = bCONTENT;
	}
	
	
}