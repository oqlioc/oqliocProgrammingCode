package obs1;

public interface Customer {

    void Updata();
}